from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *

def index(request):
    context = {
        "courses": Course.objects.all()
        }
    return render(request, 'index.html', context)

def create(request):
    errors = Course.objects.validator(request.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(request, value)
    else:
        Course.objects.create(
            name=request.POST['name'],
            description=request.POST['description']
            )

    return redirect("/")

def delete(request, id):
    if request.method == "GET":
        context = {
            "course": Course.objects.get(id=id)
        }
        return render(request,'delete.html', context)

def update(request, id):
    if request.method == "POST":
        course = Course.objects.get(id=id)
        course.delete()
    return redirect("/")
