from django.shortcuts import render, redirect
from .models import Show

def index(request):
    context = {
        'all_shows': Show.objects.all()
    }
    print(context)
    return render(request, "all_shows.html", context)

# def edit_show(request):
#     return render(request, "edit_show.html")

def new_show(request):
    return render(request, "new_show.html")

def tv_show(request, id):
    context = {
        'show': Show.objects.get(id=id)
    }
    return render(request, "tv_show.html", context)

# Create New Show
def create(request):
    show = Show.objects.create(
        title = request.POST['title'],
        network = request.POST['network'],
        release_date = request.POST['release_date'],
        description = request.POST['description']
    )
    return redirect(f'/tv_show/{show.id}')

# Edit Show
def edit(request, id):
    one_show = Show.objects.get(id=id)
    context = {
        'show': one_show
    }
    return render(request, 'edit_show.html', context)

# Update Show
def update(request, show_id):
    to_update = Show.objects.get(id=show_id)
    to_update.title = request.POST['title']
    to_update.release_date = request.POST['release_date']
    to_update.network = request.POST['network']
    to_update.description = request.POST['description']
    to_update.save()

    return redirect('/')

# Delete Show
def delete(request, show_id):
    to_delete = Show.objects.get(id=show_id)
    to_delete.delete()
    return redirect('/')

