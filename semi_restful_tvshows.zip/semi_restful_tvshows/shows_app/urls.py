from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('edit_show/<id>', views.edit),
    path('new_show/', views.new_show),
    path('tv_show/<id>', views.tv_show),
    path('create', views.create),
    path('shows/<show_id>/update', views.update),
    path('<show_id>/delete', views.delete)
]