from django.shortcuts import render, redirect
import random

GOLD = {
    "farm": (10,20),
    "cave": (5,10),
    "house": (2,5),
    "casino": (0,50)
}

def index(request):
    if"gold" not in request.session:
        request.session['gold']=0
    return render(request, "index.html")

def process(request):
    if request.method == 'POST':
        print(request.POST)
        # farm
        if request.POST['place'] == "farm":
            print("you visited the farm")
            request.session['gold']+=round(random.random()*10+10)
        # cave
        elif request.POST['place'] == "cave":
            print("you visited the cave")
            request.session['gold']+=round(random.random()*5+5)
        # house
        elif request.POST['place'] == "house":
            print("you visited the house")
            request.session['gold']+=round(random.random()*2+3)
        # casino
        else:
            print("you visited the casino, GOOD LUCK!")
            request.session['gold']+=round(random.random()*100+-50)

    return redirect('/')

def reset(request):
    request.session.flush()
    return redirect('/')