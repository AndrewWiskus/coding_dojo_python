from django.shortcuts import render, redirect
LANGS = (
    'Python',
    'English',
    'Greek'
)
LOCATIONS = (
    'San Jose',
    'Minneapolis',
    'Mars'
)


def index(request):
    context = {
        'location': LOCATIONS,
        'language': LANGS
    }
    return render(request, 'index.html', context)

def process_results(request):
    if request.method == 'GET':
        return redirect('/')
    request.session['result'] = {
        'name': request.POST['name'],
        'location': request.POST['location'],
        'language': request.POST['language'],
        'comment': request.POST['comment']
    }
    return redirect('/result')

def result(request):
    context = {
        'result': request.session['result']
    }
    return render(request, 'result.html', context)